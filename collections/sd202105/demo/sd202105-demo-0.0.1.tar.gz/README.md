# Ansible Collection - demo.hello

Software Design 2021年5月号のAnsible問題解決マップで紹介したデモ用のCollectionです。利用方法は以下の通りです。

demo collectionのアーカイブをビルドする

```
TBD
```

Private Galaxy上にネームスペース(`sd202105`)を作成してアップロードする

```
TBD
```

`ansible-galaxy`コマンドでダウンロードして利用する

```
TBD
```
